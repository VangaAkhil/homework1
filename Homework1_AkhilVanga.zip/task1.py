def print_hello():

  print("Hello Replit!")
